import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import urllib.parse
import urllib.request
import json
import os

ADDON = xbmcaddon.Addon()
DATA_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
STATE_FILE = os.path.join(DATA_DIR, "bhsxtream_state.json")


def load_state():
    try:
        if xbmcvfs.exists(STATE_FILE):
            with xbmcvfs.File(STATE_FILE, "r") as f:
                d = json.loads(f.read())
                if isinstance(d, dict):
                    return d
    except Exception:
        pass
    return {"current": None, "history": {}, "streams": {}}


def save_state(d):
    try:
        if not xbmcvfs.exists(DATA_DIR):
            xbmcvfs.mkdirs(DATA_DIR)
        with xbmcvfs.File(STATE_FILE, "w") as f:
            f.write(json.dumps(d, ensure_ascii=False))
    except Exception:
        pass


def parse_num(value):
    try:
        return float(value)
    except Exception:
        return 0.0


def next_episode_url(info, state):
    series_id = info.get('series_id')
    season = int(parse_num(info.get('season_num')))
    ep = parse_num(info.get('episode_num'))
    episodes = []
    url = f"{info.get('server')}/player_api.php?username={urllib.parse.quote(info.get('username',''))}&password={urllib.parse.quote(info.get('password',''))}&action=get_series_info&series_id={urllib.parse.quote(str(series_id))}"
    try:
        req = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=6) as response:
            data = json.loads(response.read().decode('utf-8', errors='ignore'))
        eps = data.get('episodes', {}) if isinstance(data, dict) else {}
        for s in sorted(eps.keys(), key=lambda x: int(x) if str(x).isdigit() else 999999):
            sn = int(s) if str(s).isdigit() else 999999
            for e in eps.get(s, []) or []:
                en = parse_num(e.get('episode_num'))
                if (sn > season) or (sn == season and en > ep):
                    stream_id = e.get('id')
                    ext = e.get('container_extension', 'mp4')
                    stream_url = f"{info.get('server')}/series/{info.get('username')}/{info.get('password')}/{stream_id}.{ext}"
                    return stream_url, {
                        'series_id': str(series_id), 'series_nome': info.get('series_nome',''), 'season_num': str(sn),
                        'episode_num': str(e.get('episode_num','1')), 'title': e.get('title','Sem Título'),
                        'capa': (e.get('info') or {}).get('movie_image') or info.get('capa',''), 'ext': ext,
                        'server': info.get('server'), 'username': info.get('username'), 'password': info.get('password')
                    }
    except Exception:
        return None, None
    return None, None


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = xbmc.Player()
        self.playing_url = None
        self.info = None
        self.skipped = False
        self.last_save = 0

    def onAVStarted(self):
        self.capture()
        if not self.info:
            return
        if self.skipped:
            return
        try:
            state = load_state()
            key = str(self.info.get('series_id'))+":"+str(self.info.get('season_num'))+":"+str(self.info.get('episode_num'))
            saved = state.get('history', {}).get(key, {})
            resume_pos = float(saved.get('position', 0) or 0)
            resume_dur = float(saved.get('duration', 0) or 0)
            # Resume only when there is a meaningful saved position and the episode was not finished.
            if resume_pos > 15 and (resume_dur <= 0 or resume_pos < resume_dur - 30) and not saved.get('completed', False):
                self.player.seekTime(resume_pos)
                self.skipped = True
                return
        except Exception:
            pass
        if ADDON.getSettingBool('pular_intro'):
            seconds = max(0, int(ADDON.getSettingInt('segundos_intro')))
            if seconds > 0:
                try:
                    self.player.seekTime(seconds)
                    self.skipped = True
                except Exception:
                    pass

    def onPlayBackStarted(self):
        self.capture()

    def onPlayBackEnded(self):
        self.capture()
        self.finish(True)

    def onPlayBackStopped(self):
        self.capture()
        self.finish(False)

    def capture(self):
        try:
            url = self.player.getPlayingFile()
        except Exception:
            return
        if not url:
            return
        state = load_state()
        info = state.get('streams', {}).get(url)
        if info:
            if url != self.playing_url:
                self.playing_url = url
                self.info = info
                self.skipped = False
            else:
                self.info = info
            state['current'] = info
            save_state(state)

    def finish(self, ended):
        if not self.info or not self.playing_url:
            self.reset()
            return
        try:
            pos = float(self.player.getTime())
        except Exception:
            pos = 0.0
        try:
            dur = float(self.player.getTotalTime())
        except Exception:
            dur = 0.0
        data = load_state()
        key = str(self.info.get('series_id'))+":"+str(self.info.get('season_num'))+":"+str(self.info.get('episode_num'))
        hist = data.setdefault('history', {})
        rec = dict(self.info)
        rec.update({'stream_url':self.playing_url,'position':0.0 if ended else pos,'duration':dur,'completed':bool(ended),'key':key})
        if ended:
            hist.pop(key, None)
        else:
            hist[key] = rec
        data['current'] = None if ended else rec
        save_state(data)
        if ended and ADDON.getSettingBool('proximo_episodio'):
            nxt_url, nxt_info = next_episode_url(self.info, data)
            if nxt_url and nxt_info:
                data = load_state()
                data.setdefault('streams', {})[nxt_url] = nxt_info
                data['current'] = nxt_info
                save_state(data)
                xbmc.sleep(500)
                try:
                    self.player.play(nxt_url)
                except Exception:
                    pass
        self.reset()

    def reset(self):
        self.playing_url = None
        self.info = None
        self.skipped = False

monitor=Monitor()
while not monitor.abortRequested():
    monitor.capture()
    if monitor.info:
        try:
            pos=float(monitor.player.getTime())
            dur=float(monitor.player.getTotalTime())
        except Exception:
            pos=dur=0.0
        if pos > 0:
            data=load_state()
            key=str(monitor.info.get('series_id'))+":"+str(monitor.info.get('season_num'))+":"+str(monitor.info.get('episode_num'))
            rec=dict(monitor.info)
            rec.update({'stream_url':monitor.playing_url,'position':pos,'duration':dur,'completed':False,'key':key})
            data.setdefault('history',{})[key]=rec
            data['current']=rec
            save_state(data)
    monitor.waitForAbort(5)
