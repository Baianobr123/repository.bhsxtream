import sys
import urllib.parse
import urllib.request
import json
import re
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
DATA_DIR = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
STATE_FILE = os.path.join(DATA_DIR, "bhsxtream_state.json")
WELCOME_FILE = os.path.join(DATA_DIR, "welcome_shown.flag")


def _ensure_data_dir():
    try:
        if not xbmcvfs.exists(DATA_DIR):
            xbmcvfs.mkdirs(DATA_DIR)
    except Exception:
        pass


def carregar_estado():
    _ensure_data_dir()
    try:
        if xbmcvfs.exists(STATE_FILE):
            with xbmcvfs.File(STATE_FILE, "r") as f:
                data = json.loads(f.read())
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {"current": None, "history": {}, "streams": {}}


def salvar_estado(data):
    _ensure_data_dir()
    try:
        tmp = STATE_FILE + ".tmp"
        with xbmcvfs.File(tmp, "w") as f:
            f.write(json.dumps(data, ensure_ascii=False))
        xbmcvfs.delete(STATE_FILE)
        xbmcvfs.rename(tmp, STATE_FILE)
    except Exception:
        pass


def mostrar_boas_vindas():
    _ensure_data_dir()
    try:
        if xbmcvfs.exists(WELCOME_FILE):
            return
        dialogo = xbmcgui.Dialog()
        dialogo.ok("Bem-vindo ao Cine Mundo BHS!", "Obrigado por usar o BHSXTREAM.\n\nAgora você pode assistir TV, filmes, séries e animes pelo Kodi.")
        with xbmcvfs.File(WELCOME_FILE, "w") as f:
            f.write("1")
    except Exception:
        pass


def salvar_stream_series(stream_url, info):
    data = carregar_estado()
    streams = data.setdefault("streams", {})
    streams[stream_url] = info
    # Keep the mapping bounded so the file never grows without limit.
    if len(streams) > 4000:
        for key in list(streams.keys())[:-3500]:
            streams.pop(key, None)
    salvar_estado(data)


def obter_historico():
    data = carregar_estado()
    return data.setdefault("history", {})


def salvar_historico(stream_url, position=0.0, duration=0.0, completed=False):
    data = carregar_estado()
    streams = data.setdefault("streams", {})
    info = streams.get(stream_url)
    if not info:
        return
    key = str(info.get("series_id")) + ":" + str(info.get("season_num")) + ":" + str(info.get("episode_num"))
    history = data.setdefault("history", {})
    rec = dict(info)
    rec.update({"stream_url": stream_url, "position": float(position or 0), "duration": float(duration or 0), "completed": bool(completed), "updated": xbmc.getInfoLabel("System.Date(yyyy-mm-ddThh:MM:ss)"), "key": key})
    history[key] = rec
    data["current"] = None if completed else rec
    # Keep most recent 100 history entries.
    if len(history) > 100:
        ordered = sorted(history.items(), key=lambda kv: kv[1].get("updated", ""), reverse=True)[:100]
        data["history"] = dict(ordered)
    salvar_estado(data)


def limpar_concluido(info):
    data = carregar_estado()
    history = data.get("history", {})
    key = str(info.get("series_id")) + ":" + str(info.get("season_num")) + ":" + str(info.get("episode_num"))
    history.pop(key, None)
    if data.get("current", {}).get("key") == key:
        data["current"] = None
    salvar_estado(data)

# Link Raw do seu Pastebin com a lista de servidores em formato JSON
URL_SERVIDORES_JSON = "https://pastebin.com/raw/wU0YrUiU"

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])

CAPA_PADRAO = "https://images.tmdb.org/t/p/w500/orS79T06mX6Zmdorv5g7Zf7fV4B.jpg"
TERMOS_PROIBIDOS = ["xxx", "adulto", "porn", "sexy", "erotico", "hentai", "18+", "playboy", "venus", "redlight"]

def obter_lista_servidores():
    try:
        req = urllib.request.Request(URL_SERVIDORES_JSON, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            dados = json.loads(response.read().decode('utf-8', errors='ignore'))
            if isinstance(dados, list) and len(dados) > 0:
                return dados
    except Exception:
        pass
    # Servidor de segurança (fallback) caso falhe a internet
    return [{"key": "servidor1", "nome": "Servidor 1", "server": "http://falxntc.sbs", "username": "348754786", "password": "826234227"}]

def obter_servidor_atual():
    lista = obter_lista_servidores()
    s_nome = addon.getSetting("servidor_ativo")
    if not s_nome and len(lista) > 0:
        s_nome = lista[0]["nome"]
    for serv in lista:
        if serv["nome"] == s_nome:
            return serv
    return lista[0]

def salvar_servidor_atual(s_nome):
    addon.setSetting("servidor_ativo", s_nome)

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def requisitar_api(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            return json.loads(response.read().decode('utf-8', errors='ignore'))
    except Exception:
        return None

def router(paramstring):
    mostrar_boas_vindas()
    params = {}
    if paramstring:
        clean_params = paramstring.lstrip('?')
        params = dict(urllib.parse.parse_qsl(clean_params))
    action = params.get('action')
    if not action:
        listar_menu_principal()
    elif action == 'escolher_servidor':
        dialogo_escolher_servidor()
    elif action == 'ativar_servidor':
        definir_servidor_por_nome(params.get('nome_serv'))
    elif action == 'categorias':
        listar_categorias_por_tipo(params.get('tipo'))
    elif action == 'pesquisar_secao':
        dialogo_pesquisa_secao(params.get('tipo'))
    elif action == 'resultado_secao':
        executar_pesquisa_secao(params.get('tipo'), params.get('termo'))
    elif action == 'itens':
        listar_conteudos_categoria(params.get('tipo'), params.get('cat_id'))
    elif action == 'temporadas':
        listar_temporadas(params.get('series_id'), params.get('series_nome', ''))
    elif action == 'episodios':
        listar_episodios(params.get('series_id'), params.get('season_num'), params.get('series_nome', ''))
    elif action == 'continuar':
        abrir_continuar()


def listar_menu_principal():
    serv_atual = obter_servidor_atual()
    li_serv = xbmcgui.ListItem(label=f"[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] [COLOR cyan]Servidor Atual:[/COLOR] [COLOR lime]{serv_atual['nome']}[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'action': 'escolher_servidor'}), listitem=li_serv, isFolder=True)

    current = carregar_estado().get("current")
    if current and not current.get("completed"):
        nome = current.get("series_nome", "Série")
        temp = current.get("season_num", "?")
        ep = current.get("episode_num", "?")
        pos = int(current.get("position", 0))
        label = f"[B][COLOR lime]▶ CONTINUAR ASSISTINDO[/COLOR][/B] - {nome} | T{temp}E{ep}"
        if pos > 0:
            label += f" ({pos // 60}m)"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': current.get('capa') or CAPA_PADRAO, 'thumb': current.get('capa') or CAPA_PADRAO})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'action':'continuar'}), listitem=li, isFolder=False)

    menu_principal = [
        {"name": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] TV ao Vivo[/B]", "tipo": "live"},
        {"name": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] Filmes[/B]", "tipo": "vod"},
        {"name": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] Séries e Animes[/B]", "tipo": "series"}
    ]
    for item in menu_principal:
        li = xbmcgui.ListItem(label=item['name'])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'action': 'categorias', 'tipo': item['tipo']}), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)


def abrir_continuar():
    current = carregar_estado().get("current")
    if not current or not current.get("stream_url"):
        xbmcgui.Dialog().notification("Cine Mundo BHS", "Não há reprodução para continuar.", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Update(%s, replace)' % base_url)
        return
    xbmc.Player().play(current['stream_url'])


def dialogo_escolher_servidor():
    lista = obter_lista_servidores()
    serv_atual = obter_servidor_atual()
    
    for s in lista:
        ativo = " [COLOR lime](Ativo)[/COLOR]" if s['nome'] == serv_atual['nome'] else ""
        nome_exibicao = f"[B]{s['nome']}{ativo}[/B]"
        
        url = build_url({'action': 'ativar_servidor', 'nome_serv': s['nome']})
        li = xbmcgui.ListItem(label=nome_exibicao)
        li.setArt({'icon': CAPA_PADRAO, 'thumb': CAPA_PADRAO})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def definir_servidor_por_nome(nome_serv):
    if nome_serv:
        salvar_servidor_atual(nome_serv)
        xbmcgui.Dialog().notification("Cine Mundo BHS", f"Trocado para: {nome_serv}", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Update(%s, replace)' % base_url)

def listar_categorias_por_tipo(tipo):
    serv = obter_servidor_atual()
    base_url_api = f"{serv['server']}/player_api.php?username={serv['username']}&password={serv['password']}"
    
    titulos_pesquisa = {
        "live": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] Pesquisar Canal de TV...",
        "vod": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] Pesquisar Filme...",
        "series": "[B] [COLOR white]Cine[/COLOR] [COLOR red]Mundo[/COLOR] [COLOR gold]||[/COLOR] Pesquisar Série / Anime..."
    }
    
    url_busca = build_url({'action': 'pesquisar_secao', 'tipo': tipo})
    li_busca = xbmcgui.ListItem(label=f"[B][COLOR yellow]{titulos_pesquisa.get(tipo, 'Pesquisar...')}[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_busca, listitem=li_busca, isFolder=True)

    action_cat = "get_live_categories" if tipo == "live" else ("get_vod_categories" if tipo == "vod" else "get_series_categories")
    cats = requisitar_api(f"{base_url_api}&action={action_cat}")
    
    if cats and isinstance(cats, list):
        for cat in cats:
            cat_id = str(cat.get('category_id'))
            cat_name = cat.get('category_name', 'Categoria')
            
            if not any(t in cat_name.lower() for t in TERMOS_PROIBIDOS):
                url = build_url({'action': 'itens', 'tipo': tipo, 'cat_id': cat_id})
                li = xbmcgui.ListItem(label=cat_name)
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
                
    xbmcplugin.endOfDirectory(addon_handle)

def dialogo_pesquisa_secao(tipo):
    teclado = xbmc.Keyboard('', 'Digite o que deseja pesquisar:')
    teclado.doModal()
    if teclado.isConfirmed():
        termo = teclado.getText()
        if termo:
            executar_pesquisa_secao(tipo, termo)

def executar_pesquisa_secao(tipo, termo):
    serv = obter_servidor_atual()
    base_url_api = f"{serv['server']}/player_api.php?username={serv['username']}&password={serv['password']}"
    termo_lower = termo.lower()
    encontrou = False

    xbmc.executebuiltin("ActivateWindow(busydialog)")

    action_stream = "get_live_streams" if tipo == "live" else ("get_vod_streams" if tipo == "vod" else "get_series")
    itens = requisitar_api(f"{base_url_api}&action={action_stream}")

    if itens and isinstance(itens, list):
        for item in itens:
            nome_bruto = item.get('name') or item.get('title') or "Sem Nome"
            if termo_lower in nome_bruto.lower():
                
                if tipo == "live":
                    logo = item.get('stream_icon') or CAPA_PADRAO
                    if not str(logo).startswith('http'): logo = CAPA_PADRAO
                    stream_id = item.get('stream_id')
                    stream_url = f"{serv['server']}/live/{serv['username']}/{serv['password']}/{stream_id}.ts"
                    
                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': logo, 'thumb': logo, 'icon': logo})
                    li.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
                    encontrou = True
                    
                elif tipo == "vod":
                    stream_id = item.get('stream_id')
                    ext = item.get('container_extension', 'mp4')
                    stream_url = f"{serv['server']}/movie/{serv['username']}/{serv['password']}/{stream_id}.{ext}"
                    capa = item.get('stream_icon') or CAPA_PADRAO
                    if not str(capa).startswith('http'): capa = CAPA_PADRAO

                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': capa, 'thumb': capa, 'fanart': capa, 'icon': capa})
                    li.setInfo('video', {'title': nome_bruto, 'mediatype': 'movie'})
                    li.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
                    encontrou = True
                    
                elif tipo == "series":
                    series_id = item.get('series_id')
                    url = build_url({'action': 'temporadas', 'series_id': series_id, 'series_nome': nome_bruto})
                    capa = item.get('cover') or CAPA_PADRAO
                    if not str(capa).startswith('http'): capa = CAPA_PADRAO

                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': capa, 'thumb': capa, 'fanart': capa, 'icon': capa})
                    li.setInfo('video', {'title': nome_bruto, 'mediatype': 'tvshow'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
                    encontrou = True

    xbmc.executebuiltin("Dialog.Close(busydialog)")

    if not encontrou:
        xbmcgui.Dialog().notification("Cine Mundo BHS", "Nenhum resultado encontrado.", xbmcgui.NOTIFICATION_INFO, 2500)

    xbmcplugin.endOfDirectory(addon_handle)

def listar_conteudos_categoria(tipo, cat_id):
    serv = obter_servidor_atual()
    base_url_api = f"{serv['server']}/player_api.php?username={serv['username']}&password={serv['password']}"
    
    action_stream = "get_live_streams" if tipo == "live" else ("get_vod_streams" if tipo == "vod" else "get_series")
    itens = requisitar_api(f"{base_url_api}&action={action_stream}")
    
    if itens and isinstance(itens, list):
        for item in itens:
            if str(item.get('category_id')) == str(cat_id):
                nome_bruto = item.get('name') or item.get('title') or "Sem Nome"
                
                if tipo == "live":
                    logo = item.get('stream_icon') or CAPA_PADRAO
                    if not str(logo).startswith('http'): logo = CAPA_PADRAO
                    stream_id = item.get('stream_id')
                    stream_url = f"{serv['server']}/live/{serv['username']}/{serv['password']}/{stream_id}.ts"
                    
                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': logo, 'thumb': logo, 'icon': logo})
                    li.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
                    
                elif tipo == "vod":
                    stream_id = item.get('stream_id')
                    ext = item.get('container_extension', 'mp4')
                    stream_url = f"{serv['server']}/movie/{serv['username']}/{serv['password']}/{stream_id}.{ext}"
                    capa_servidor = item.get('stream_icon') or CAPA_PADRAO
                    if not str(capa_servidor).startswith('http'): capa_servidor = CAPA_PADRAO

                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': capa_servidor, 'thumb': capa_servidor, 'fanart': capa_servidor, 'icon': capa_servidor})
                    li.setInfo('video', {'title': nome_bruto, 'mediatype': 'movie'})
                    li.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
                    
                elif tipo == "series":
                    series_id = item.get('series_id')
                    url = build_url({'action': 'temporadas', 'series_id': series_id, 'series_nome': nome_bruto})
                    capa_servidor = item.get('cover') or CAPA_PADRAO
                    if not str(capa_servidor).startswith('http'): capa_servidor = CAPA_PADRAO

                    li = xbmcgui.ListItem(label=nome_bruto)
                    li.setArt({'poster': capa_servidor, 'thumb': capa_servidor, 'fanart': capa_servidor, 'icon': capa_servidor})
                    li.setInfo('video', {'title': nome_bruto, 'mediatype': 'tvshow'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def listar_temporadas(series_id, series_nome):
    serv = obter_servidor_atual()
    base_url_api = f"{serv['server']}/player_api.php?username={serv['username']}&password={serv['password']}"
    
    detalhes = requisitar_api(f"{base_url_api}&action=get_series_info&series_id={series_id}")
    poster = CAPA_PADRAO
    
    if isinstance(detalhes, dict):
        info_serie = detalhes.get('info', {})
        poster = info_serie.get('cover') or CAPA_PADRAO

    if isinstance(detalhes, dict) and 'episodes' in detalhes:
        episodios_dict = detalhes['episodes']
        for temporada in sorted(episodios_dict.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            nome_temp = f"Temporada {temporada}"
            url = build_url({'action': 'episodios', 'series_id': series_id, 'season_num': temporada, 'series_nome': series_nome})
            
            li = xbmcgui.ListItem(label=nome_temp)
            li.setArt({'poster': poster, 'thumb': poster, 'fanart': poster, 'icon': poster})
            li.setInfo('video', {'title': nome_temp, 'mediatype': 'season'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def listar_episodios(series_id, season_num, series_nome):
    serv = obter_servidor_atual()
    base_url_api = f"{serv['server']}/player_api.php?username={serv['username']}&password={serv['password']}"
    detalhes = requisitar_api(f"{base_url_api}&action=get_series_info&series_id={series_id}")
    if isinstance(detalhes, dict) and 'episodes' in detalhes:
        episodios_dict = detalhes['episodes']
        eps_da_temporada = episodios_dict.get(str(season_num), [])
        for idx, ep in enumerate(eps_da_temporada):
            num_ep = ep.get('episode_num', '1')
            titulo_ep = f"Episódio {num_ep} - {ep.get('title', 'Sem Título')}"
            ep_id = ep.get('id')
            ext = ep.get('container_extension', 'mp4')
            stream_url = f"{serv['server']}/series/{serv['username']}/{serv['password']}/{ep_id}.{ext}"
            info_ep = ep.get('info', {})
            capa_ep = info_ep.get('movie_image') or CAPA_PADRAO
            info = {
                'series_id': str(series_id), 'series_nome': series_nome, 'season_num': str(season_num),
                'episode_num': str(num_ep), 'title': ep.get('title', 'Sem Título'), 'capa': capa_ep,
                'ext': ext, 'server': serv['server'], 'username': serv['username'], 'password': serv['password']
            }
            salvar_stream_series(stream_url, info)
            hist = obter_historico().get(str(series_id)+":"+str(season_num)+":"+str(num_ep), {})
            label = titulo_ep
            if hist and hist.get('position', 0) > 10 and not hist.get('completed'):
                label += f" [COLOR yellow]({int(hist.get('position',0)//60)}m)[/COLOR]"
            li = xbmcgui.ListItem(label=label)
            li.setArt({'poster': capa_ep, 'thumb': capa_ep, 'fanart': capa_ep, 'icon': capa_ep})
            li.setInfo('video', {'title': titulo_ep, 'season': int(float(season_num)), 'episode': int(float(num_ep)), 'mediatype': 'episode'})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)


if __name__ == '__main__':
    param_str = sys.argv[2] if len(sys.argv) > 2 else ""
    router(param_str)
