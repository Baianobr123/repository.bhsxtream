import json
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os

ADDON = xbmcaddon.Addon()
DATA_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
STATE_FILE = os.path.join(DATA_DIR, 'bhsxtream_state.json')


def load_state():
    try:
        if xbmcvfs.exists(STATE_FILE):
            with xbmcvfs.File(STATE_FILE, 'r') as f:
                data = json.loads(f.read())
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {'current': None, 'history': {}, 'streams': {}}


def save_state(data):
    try:
        if not xbmcvfs.exists(DATA_DIR):
            xbmcvfs.mkdirs(DATA_DIR)
        tmp = STATE_FILE + '.tmp'
        with xbmcvfs.File(tmp, 'w') as f:
            f.write(json.dumps(data, ensure_ascii=False))
        if xbmcvfs.exists(STATE_FILE):
            xbmcvfs.delete(STATE_FILE)
        xbmcvfs.rename(tmp, STATE_FILE)
    except Exception:
        pass


def hist_key(info):
    return '{}:{}:{}'.format(info.get('series_id', ''), info.get('season_num', ''), info.get('episode_num', ''))


class BHSPlayer(xbmc.Player):
    """Monitora apenas URLs previamente registradas pelo plugin como episódios."""
    def __init__(self):
        super().__init__()
        self.current_url = ''
        self.current_info = None
        self.handled_end = False
        self.last_write = 0.0

    def capture(self):
        try:
            url = self.getPlayingFile()
        except Exception:
            return False
        if not url:
            return False
        state = load_state()
        info = state.get('streams', {}).get(url)
        if not info:
            # TV ao vivo e filmes não registrados: nenhuma ação.
            return False
        if url != self.current_url:
            self.current_url = url
            self.current_info = info
            self.handled_end = False
        else:
            self.current_info = info
        return True

    def save_progress(self, completed=False):
        if not self.current_url or not self.current_info:
            return
        try:
            position = max(0.0, float(self.getTime()))
            duration = max(0.0, float(self.getTotalTime()))
        except Exception:
            return
        state = load_state()
        info = dict(self.current_info)
        key = hist_key(info)
        rec = dict(info)
        rec.update({
            'stream_url': self.current_url,
            'position': 0.0 if completed else position,
            'duration': duration,
            'completed': bool(completed),
            'updated': time.time(),
            'key': key
        })
        history = state.setdefault('history', {})
        if completed:
            history.pop(key, None)
            state['current'] = None
        else:
            history[key] = rec
            state['current'] = rec
        state['streams'][self.current_url] = info
        save_state(state)

    def onPlayBackStarted(self):
        self.capture()

    def onAVStarted(self):
        self.capture()

    def onPlayBackStopped(self):
        # Somente salva se o stream atual estiver registrado pelo BHSXTREAM.
        if self.capture():
            self.save_progress(False)
        self.reset()

    def onPlayBackEnded(self):
        if not self.capture():
            self.reset()
            return
        info = dict(self.current_info or {})
        self.save_progress(True)
        if self.handled_end or ADDON.getSetting('proximo_episodio') == 'false':
            self.reset()
            return
        self.handled_end = True
        next_url = info.get('next_stream_url', '')
        next_info = info.get('next_info', {}) or {}
        if not next_url or not next_info:
            self.reset()
            return

        state = load_state()
        state.setdefault('streams', {})[next_url] = next_info
        next_rec = dict(next_info)
        next_rec.update({'stream_url': next_url, 'position': 0.0, 'duration': 0.0, 'completed': False, 'updated': time.time(), 'key': hist_key(next_info)})
        state.setdefault('history', {})[hist_key(next_info)] = next_rec
        state['current'] = next_rec
        save_state(state)

        # Aguarda a transição do player e inicia SOMENTE o próximo episódio registrado.
        xbmc.sleep(350)
        try:
            item = xbmcgui.ListItem(label=next_info.get('title', 'Próximo episódio'))
            item.setProperty('IsPlayable', 'true')
            self.play(next_url, item)
        except Exception:
            pass
        self.reset()

    def reset(self):
        self.current_url = ''
        self.current_info = None
        self.handled_end = False
        self.last_write = 0.0


player = BHSPlayer()
monitor = xbmc.Monitor()
while not monitor.abortRequested():
    if monitor.waitForAbort(3.0):
        break
    try:
        if player.isPlayingVideo() and player.capture():
            now = time.time()
            if now - player.last_write >= 8.0:
                player.last_write = now
                player.save_progress(False)
    except Exception:
        pass
